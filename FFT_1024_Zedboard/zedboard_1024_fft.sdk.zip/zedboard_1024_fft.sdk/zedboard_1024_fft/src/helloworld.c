#include <stdio.h>
#include <stdlib.h>
#include "platform.h"
#include "xil_printf.h"
#include <complex.h>
#include <xtime_l.h>
#include "dma_init.h"
#include "xparameters.h"
#include "xaxidma.h"
#include <math.h>

#define N 1024
#define PI 3.14159265358979323846

// Function to reverse bits of a number
unsigned int bit_reverse(unsigned int x, int log2n) {
    int n = 0;
    for (int i = 0; i < log2n; i++) {
        n <<= 1;
        n |= (x & 1);
        x >>= 1;
    }
    return n;
}

// FFT function
void fft(complex float *X, int log2n) {
    int n = 1 << log2n; // n = 2^log2n = 1024
    complex double W[n / 2];

    // twiddle factors
    for (int i = 0; i < n / 2; i++) {
        double theta = -2.0 * PI * i / n;
        W[i] = cos(theta) + I * sin(theta);
    }

    // Bit-reversal
    for (int i = 0; i < n; i++) {
        int j = bit_reverse(i, log2n);
        if (j > i) {
            complex double temp = X[i];
            X[i] = X[j];
            X[j] = temp;
        }
    }

    // Cooley-Tukey FFT
    for (int s = 1; s <= log2n; s++) {
        int m = 1 << s; // m = 2^s
        int m2 = m / 2;
        for (int j = 0; j < m2; j++) {
            complex double w = W[j * (n / m)];
            for (int k = j; k < n; k += m) {
                complex double t = w * X[k + m2];
                complex double u = X[k];
                X[k] = u + t;
                X[k + m2] = u - t;
            }
        }
    }
}

int main() {
    init_platform();

    XTime PS_start_time, PS_end_time;
    XTime PL_start_time, PL_end_time;

    float complex FFT_input[N];

    for (int i = 0; i < N; i++) {
        FFT_input[i] = i + 1.0 + (i + 1.0) * I;
    }

    float complex FFT_output_sw[N], FFT_output_hw[N];

    ////////////Hardware 1024 point FFT
    int status;

    XAxiDma AxiDMA;
    status = DMA_Init(&AxiDMA, XPAR_AXI_DMA_0_DEVICE_ID);

    if (status)
        return 1;  // DMA Init failed

    Xil_DCacheFlushRange((UINTPTR)FFT_input, ((sizeof(float complex))*N));

    XTime_SetTime(0);
    XTime_GetTime(&PL_start_time);

    // Simple DMA transfers
    status = XAxiDma_SimpleTransfer(&AxiDMA, (UINTPTR)FFT_output_hw, ((sizeof(float complex)) * N), XAXIDMA_DEVICE_TO_DMA);
    if (status != XST_SUCCESS) return XST_FAILURE;

    status = XAxiDma_SimpleTransfer(&AxiDMA, (UINTPTR)FFT_input, ((sizeof(float complex)) * N), XAXIDMA_DMA_TO_DEVICE);
    if (status != XST_SUCCESS) return XST_FAILURE;

    // Check whether transfers are complete
    while (XAxiDma_Busy(&AxiDMA, XAXIDMA_DMA_TO_DEVICE));
    while (XAxiDma_Busy(&AxiDMA, XAXIDMA_DEVICE_TO_DMA));

    XTime_GetTime(&PL_end_time);

    Xil_DCacheInvalidateRange((UINTPTR)FFT_output_hw, ((sizeof(float complex))*N));

    /////////////Software 1024 point FFT

    // Copy input to output array for software FFT
    for (int i = 0; i < N; i++) {
        FFT_output_sw[i] = FFT_input[i];
    }

    XTime_SetTime(0);
    XTime_GetTime(&PS_start_time);

    // Perform software FFT
    fft(FFT_output_sw, 10); // 2^10 = 1024 points FFT

    XTime_GetTime(&PS_end_time);

    ////////////////////////Verifying hardware and software results
    for (int i = 0; i < N; i++) {
        printf("\n\rPS Output: %f + %fI, PL Output: %f + %fI", crealf(FFT_output_sw[i]),
            cimagf(FFT_output_sw[i]), crealf(FFT_output_hw[i]), cimagf(FFT_output_hw[i]));
        float diff1 = fabsf(crealf(FFT_output_sw[i]) - crealf(FFT_output_hw[i]));
        float diff2 = fabsf(cimagf(FFT_output_sw[i]) - cimagf(FFT_output_hw[i]));

        if (diff1 >= 5 && diff2 >= 5) {
            printf("\n\rData Mismatch found at index %d!", i);
            break;
        } else {
            printf("\nDMA transfer successful!");
        }
    }

    ///////////////Hardware and Software Execution Time Calculation

    float time = 0;
    time = (float)1.0 * (PS_end_time - PS_start_time) / (COUNTS_PER_SECOND / 1000000);
    printf("\n\rExecution time for PS in microseconds: %f", time);

    time = 0;
    time = (float)1.0 * (PL_end_time - PL_start_time) / (COUNTS_PER_SECOND / 1000000);
    printf("\n\rExecution time for PL in microseconds: %f", time);

    cleanup_platform();
    return 0;
}
